//
//  CollectionReusableView.swift
//  AssignmentiOS
//
//  Created by Mohit Tomar on 05/04/19.
//  Copyright © 2019 Mohit Tomar. All rights reserved.
//

import UIKit

class CollectionReusableView: UICollectionReusableView {

    @IBOutlet weak var view: UIView!
    @IBOutlet weak var imgV: UIImageView!
    @IBOutlet weak var Lbl: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        nibSetup()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        nibSetup()
    }
    
    
    private func nibSetup() {
        backgroundColor = .clear
        view  = loadViewFromNib()
        view.frame = bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.translatesAutoresizingMaskIntoConstraints = true
        //view.backgroundColor = .red
        addSubview(view)
    }
    
    
    private func loadViewFromNib() -> UIView {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: "CollectionReusableView", bundle: bundle)
        let nibView = nib.instantiate(withOwner: self, options: nil).first as! UIView
        
        return nibView
        
    }
    
    func setData (user : User){
        self.imgV.sd_setImage(with: URL(string:user.userImage), placeholderImage:#imageLiteral(resourceName: "loading"))
        self.imgV.layer.cornerRadius = self.imgV.frame.width / 2
        self.Lbl.text = user.userName
    }
}
