//
//  Constants.swift
//  Troove
//
//  Created by Mohit Tomar on 16/10/18.
//  Copyright © 2018 MohitTomar. All rights reserved.
//


import Foundation
import UIKit

let kBaseUrl = "http://sd2-hiring.herokuapp.com/api/" //

let kUserDefaults = UserDefaults.standard
let kAppDelegate = UIApplication.shared.delegate as! AppDelegate



struct API {
    static let kUsersApi = kBaseUrl + "users"
    
}

struct WebLinks {
    
}

struct StatusCode {
    static let success = true
    static let failure = false
}



struct ServerKey {
    static let statusCode = "status"
    static let data = "data"
    static let message = "message"
    static let users = "users"
    static let name = "name"
    static let image = "image"
    static let items = "items"
    static let more = "has_more"    
    static let offset = "offset"
    static let limit = "limit"
   
}


