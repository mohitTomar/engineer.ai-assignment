//
//  Constants.swift
//  Troove
//
//  Created by Mohit Tomar on 16/10/18.
//  Copyright © 2018 MohitTomar. All rights reserved.
//


import SwiftyJSON

extension NSError {
    
    static func api(response:JSON) -> NSError {
        return NSError(
            domain: "",
            code: response[ServerKey.statusCode].intValue,
            userInfo: [
                NSLocalizedDescriptionKey :  response[ServerKey.message].stringValue ,
                NSLocalizedFailureReasonErrorKey : response[ServerKey.message].stringValue
            ])
    }
    
    static func someWentWrong() -> NSError {
        return NSError(domain: "ServerErrorDomain", code: 601, userInfo:  [
            NSLocalizedDescriptionKey :  "Something went wrong" ,
            NSLocalizedFailureReasonErrorKey : "failed"])
    }

    static func cameraGalleryError(error:String) -> NSError {
        return NSError(domain: "Media Error", code: 404, userInfo:  [
            NSLocalizedDescriptionKey :  error ,
            NSLocalizedFailureReasonErrorKey : "failed"])
    }
}

