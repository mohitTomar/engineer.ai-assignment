//
//  myUser.swift
//  Troove
//
//  Created by MohitTomar on 12/13/18.
//  Copyright © 2018 Mohit Tomar. All rights reserved.
//

import SwiftyJSON

class User {
    
    var userName = ""
    var userImage = ""
    var userItems = [String]()

    init(user : JSON) {
        self.userName = user[ServerKey.name].stringValue
        self.userImage = user[ServerKey.image].stringValue
        let arr = user[ServerKey.items].arrayValue
      
        for item in arr {
            self.userItems.append(item.stringValue)
        }
        
    }
    
    
    static func userList(params:[String:Any]?, completionHandler:@escaping (_ users:[User]?, _ more:Bool?, _ error:NSError?)->()) {
        APIManager.apiGet(serviceName: API.kUsersApi, parameters: params) { (response:JSON?, error:NSError?) in
            if let error = error {
                completionHandler(nil, false, error)
                return
            }
            guard let response = response else {
                completionHandler(nil, false, NSError.someWentWrong())
                return
            }
            if response[ServerKey.statusCode].boolValue == StatusCode.success {
                
                print("array response \(response)")
                var users = Array<User>()
                for tempUser in response[ServerKey.data][ServerKey.users].arrayValue {
                    users.append(User(user: tempUser))
                }
                
                let haveMore = response[ServerKey.data][ServerKey.more].boolValue
                
                completionHandler(users, haveMore, nil)
            } else {
                completionHandler(nil, false, NSError.api(response: response))
            }
        }
    }
    
    
}



class UserItem {
    
    var itemLink = ""
    
    init(link : JSON ) {
        self.itemLink = link.stringValue
    }
}




