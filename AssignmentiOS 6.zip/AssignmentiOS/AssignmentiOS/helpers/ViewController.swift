//
//  ViewController.swift
//  AssignmentiOS
//
//  Created by Mohit Tomar on 05/04/19.
//  Copyright © 2019 Mohit Tomar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

