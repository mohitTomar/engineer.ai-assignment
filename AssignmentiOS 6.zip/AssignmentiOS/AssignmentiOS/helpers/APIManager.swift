//
//  Constants.swift
//  Troove
//
//  Created by Mohit Tomar on 16/10/18.
//  Copyright © 2018 MohitTomar. All rights reserved.
//


import Alamofire
import SwiftyJSON

class APIManager: NSObject {

    static let authorization = "Authorization"
    
    class func apiGet(serviceName:String,parameters: [String:Any]?, completionHandler: @escaping (JSON?, NSError?) -> ()) {
        
        Alamofire.request(serviceName, method: .get, parameters: parameters, encoding: URLEncoding.default, headers: [authorization:getAccessToken()]).responseJSON { (response:DataResponse<Any>) in
            
            switch(response.result) {
            case .success(_):
                if let data = response.result.value{
                    let json = JSON(data)
                  

                    completionHandler(json,nil)
                }
                break
                
            case .failure(_):
                completionHandler(nil,response.result.error as NSError?)
                break
                
            }
        }
    }
    
   
    

    class func getAccessToken()-> String {
        
        return ""
    }
    
    
}
