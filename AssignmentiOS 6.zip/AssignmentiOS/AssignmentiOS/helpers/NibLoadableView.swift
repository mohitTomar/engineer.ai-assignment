//
//  Constants.swift
//  Troove
//
//  Created by Mohit Tomar on 16/10/18.
//  Copyright © 2018 MohitTomar. All rights reserved.
//

import UIKit

protocol NibLoadableView: class {
    static var nibName: String { get }
}

extension NibLoadableView where Self: UIView {
    static var nibName: String {
        return String(describing: self)
    }
}
