//
//  Constants.swift
//  Troove
//
//  Created by Mohit Tomar on 16/10/18.
//  Copyright © 2018 MohitTomar. All rights reserved.
//

import UIKit

class RWLoadMoreView: UIView {

    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
