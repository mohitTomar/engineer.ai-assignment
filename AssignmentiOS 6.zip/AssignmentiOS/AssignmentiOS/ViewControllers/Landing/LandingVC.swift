//
//  LandingVC.swift
//  AssignmentiOS
//
//  Created by Mohit Tomar on 05/04/19.
//  Copyright © 2019 Mohit Tomar. All rights reserved.
//

import UIKit
import SDWebImage

class LandingVC: UIViewController, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
    
    
    
    @IBOutlet weak var imageCollection : UICollectionView!
    var offset = 0
    let limit = 10
    var usersArr = Array<User>()
    var moreItem = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    
    func setupUI() {
        self.imageCollection.register(UINib(nibName:"CollectionCell", bundle: nil), forCellWithReuseIdentifier: "CollectionCell")
        self.imageCollection.register(CollectionReusableView.self,forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,withReuseIdentifier: "CollectionReusableView")
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
        getUserArray()
    }
    
    
    
    // MARK: - CollectionView
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize{
        return CGSize(width: Utilities.ScreenSize.screenWidth, height: (Utilities.ScreenSize.screenWidth/6))
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int{
        return usersArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        switch kind {
        case UICollectionView.elementKindSectionHeader:
            
            let user = usersArr[indexPath.section] as User
            let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "CollectionReusableView", for: indexPath) as! CollectionReusableView
            header.setData(user: user)
            return header
        default:
            return UICollectionReusableView()
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let user = usersArr[section] as User
        return user.userItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath) as! CollectionCell
        let user = usersArr[indexPath.section] as User
        cell.setdata(user: user, index: indexPath.row)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var cellWidth = 0.0
        let users = usersArr[indexPath.section] as User
        if users.userItems.count % 2 == 1 && indexPath.row == 0 {
            cellWidth = Double(imageCollection.frame.size.width)
            return CGSize(width: cellWidth , height:cellWidth)
        }
        cellWidth = Double((imageCollection.frame.size.width / 2.0) - 2.5)
        return CGSize(width: cellWidth , height:cellWidth)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return  UIEdgeInsets(top: 5, left: 0, bottom: 5, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat{
        return 2.5
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplaySupplementaryView view: UICollectionReusableView, forElementKind elementKind: String, at indexPath: IndexPath) {
        if indexPath.section == usersArr.count-1  && moreItem == true {
            getUserArray()
        }
    }
}
