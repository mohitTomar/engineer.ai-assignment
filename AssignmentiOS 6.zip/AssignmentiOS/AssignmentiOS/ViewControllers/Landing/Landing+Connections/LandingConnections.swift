//
//  LandingConnections.swift
//  AssignmentiOS
//
//  Created by Mohit Tomar on 05/04/19.
//  Copyright © 2019 Mohit Tomar. All rights reserved.
//

import Foundation

extension LandingVC {
    
    
    
    func getUserArray() {
        let params = [
            ServerKey.offset:offset,
            ServerKey.limit : limit,
            ] as [String : Any]
        
        
        User.userList(params: params) { [weak self] (users:[User]?, more:Bool?, error:NSError?) in
            
            if let error = error {
                
                print("error userList \(error.description)")
                return
            }
            
            guard let `self` = self, let _ = more, let _ = users else { return }
            
            if self.offset == 0 {
                self.usersArr.removeAll()
            }
            //self.totalCount = response[ServerKey.totalCount].intValue
            
            self.usersArr += users!
            self.offset = self.usersArr.count
            self.moreItem = more!
            print("self.userslistArr \(self.usersArr)")

            DispatchQueue.main.async {
                self.imageCollection.reloadData()
            }
        }
    }
    
}
