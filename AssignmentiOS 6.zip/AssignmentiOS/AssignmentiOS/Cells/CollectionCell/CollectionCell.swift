//
//  CollectionCell.swift
//  AssignmentiOS
//
//  Created by Mohit Tomar on 05/04/19.
//  Copyright © 2019 Mohit Tomar. All rights reserved.
//

import UIKit

class CollectionCell: UICollectionViewCell {

    @IBOutlet weak var imgV : UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func setdata(user : User, index : Int){
        let imgurl = user.userItems[index] as String
        self.imgV.sd_setImage(with: URL(string:imgurl), placeholderImage:#imageLiteral(resourceName: "loading"))
    }
}
